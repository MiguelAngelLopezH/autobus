var buscar = ''
//inicia el buscar con lo que hay en el formualrio en a y b
function ini(){
    buscar = '<?xml version="1.0" encoding="utf-8"?>' +
    '<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">' +
    '<Body>' +
    '<BuscarViajeRequest xmlns="http://tell.me/autobus"></BuscarViajeRequest>' +
    '</Body>' +
    '</Envelope>'
}
//lo que pasa al presionar boton, inicia buscar, hace llamado 
//al servicio web, e imprime el resultado en el txt del resultado
function soap(){
    ini();
    axios.post('http://localhost:8080/ws/autobus', buscar, {
        headers: {
            'Content-Type': 'text/xml',
            'SOAPAction' : '',
        }
    })
    .then(function(response){
        console.log(response.data);
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(response.data, "text/xml");
        var resultado = xmlDoc.getElementsByTagName("ns2:BuscarViajeResponse")[0].childNodes[0];
        
        do {
            var id = resultado.getElementsByTagName("ns2:id")[0].childNodes[0].nodeValue
            var viaje = resultado.getElementsByTagName("ns2:viaje")[0].childNodes[0].nodeValue

            fila = "<tr><td>"+id+"</td><td>"+viaje+"</td></td>";
            var tablaRef = document.getElementById('tablaviajes').getElementsByTagName('tbody')[0];
            var newRow = tablaRef.insertRow(tablaRef.rows.length);
            newRow.innerHTML = fila;

            console.log(id + ", "+ viaje);
            resultado = resultado.nextSibling;

        }while (resultado.hasChildNodes() != null);
        
    })
    .catch(err => console.log(err))
}

