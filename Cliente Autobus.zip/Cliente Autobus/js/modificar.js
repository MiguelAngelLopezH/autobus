var borrar = ''
//inicia el borrar con lo que hay en el formualrio en a y b
function ini(){
    borrar = '<?xml version="1.0" encoding="utf-8"?>' +
    '<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">' +
    '<Body>' +
    '<ModificarViajeRequest xmlns="http://tell.me/autobus">' +
    '<id>' + document.getElementById('id').value + '</id>' +
    '<viaje>' + document.getElementById('viaje').value + '</viaje>' +
    '</ModificarViajeRequest>' +
    '</Body>' +
    '</Envelope>';
}
//lo que pasa al presionar boton, inicia borrar, hace llamado 
//al servicio web, e imprime el resultado en el txt del resultado
function soap(){
    ini();
    axios.post('http://localhost:8080/ws/autobus', borrar, {
        headers: {
            'Content-Type': 'text/xml',
            'SOAPAction' : '',
        }
    })
    .then(function(response){
        console.log(response.data)
        document.getElementById('r').value = resultado(response.data)
    })
    .catch(err => console.log(err));
}
//con esto logramos imprimir el resultado en nuestro formulario
function resultado(rXml){
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(rXml, "text/xml");
    //aqui es con poner la etiqueta xml en donde se pone el resultado
    var resul = xmlDoc.getElementsByTagName("ns2:ModificarViajeResponse")[0].childNodes[0].childNodes[0].nodeValue;
    console.log(resul)
    return resul;
}
function limpiar(){
    document.getElementById("viaje").value="";
    document.getElementById("id").value="";
    document.getElementById("r").value="";
}